import React from "react";
import '../../App.css';

function RegisterFooter() {
    return (
        <>
        </>
    );
}

export default RegisterFooter;