import React from "react";
import "./Property.css";
import PropertySection from "./PropertySection";
function Property() {
    return (
        <>
            <PropertySection/>
        </>
    );
}

export default Property;