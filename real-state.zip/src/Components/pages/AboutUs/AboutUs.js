import React from 'react';
import Header from './Header';
import Content from './Content';
function AboutUs() {
    return (
        <>
        <Header />
        <Content />
        </>
    );
}

export default AboutUs;