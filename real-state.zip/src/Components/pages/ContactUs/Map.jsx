import React from "react";
function Map() {
  return (
    <>
      <div class="map">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d48339.96142392091!2d-74.55605639489661!3d40.7785707239261!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c3989fad42c315%3A0xee046946733305b1!2zTWVuZGhhbSBUb3duc2hpcCwg2Y
          bZitmIINis2YrYsdiz2YrYjCDYp9mE2YjZhNin2YrYp9iqINin2YTZhdiq2K3Yr9ip!5e0!3m2!1sar!2seg!4v1724953936280!5m2!1sar!2seg"
        ></iframe>
      </div>
    </>
  );
}

export default Map;
